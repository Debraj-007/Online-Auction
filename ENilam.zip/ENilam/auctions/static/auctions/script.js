window.addEventListener('load',()=>{
    //console.log(Timer,easyTimer)
    //var timer = new Timer();
    //timer.start({countdown: true, startValues: {seconds: 30}});

    const timerElements = document.querySelectorAll('.timer')

    for (const timerElement of timerElements){
        const time = timerElement.firstChild.innerText
        timerElement.innerHTML = new Date(time)
    }
})
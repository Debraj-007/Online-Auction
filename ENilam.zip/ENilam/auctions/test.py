import threading

def fun(obj,time):
    print(str(obj.text) + str(time))

class MyClass:
    text= 'hello world'
    type= 'custom'

obj = MyClass()

time = threading.Timer(3,fun,[obj,'3'])

print('Code Started')

print(obj)

time.start()

print('Code Ended')